from SemanticNetsAgent import SemanticNetsAgent


def test():
    # This will test your SemanticNetsAgent
    # with seven initial test cases.
    test_agent = SemanticNetsAgent()

    print(test_agent.solve(25, 1))
    print(test_agent.solve(25, 2))
    print(test_agent.solve(25, 3))
    print(test_agent.solve(25, 4))
    print(test_agent.solve(25, 5))
    print(test_agent.solve(25, 6))
    print(test_agent.solve(25, 7))
    print(test_agent.solve(25, 8))
    print(test_agent.solve(25, 9))
    print(test_agent.solve(25, 10))
    print(test_agent.solve(25, 11))
    print(test_agent.solve(25, 12))
    print(test_agent.solve(25, 13))
    print(test_agent.solve(25, 14))
    print(test_agent.solve(25, 15))
    print(test_agent.solve(25, 16))
    print(test_agent.solve(25, 17))
    print(test_agent.solve(25, 18))
    print(test_agent.solve(25, 19))
    print(test_agent.solve(25, 20))
    print(test_agent.solve(25, 21))
    print(test_agent.solve(25, 22))
    print(test_agent.solve(25, 23))
    print(test_agent.solve(25, 24))
    print(test_agent.solve(25, 25))


if __name__ == "__main__":
    test()
